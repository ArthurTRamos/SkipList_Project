#include "skiplist.h"

typedef struct no_ NO;

struct no_ {
    ITEM* item;
    int nivel;
    NO* proximo;
    NO* baixo;
};

struct skiplist_ {
    int levelmax;
    NO* upleft;
};

SKIPLIST* skip_criar() {
    SKIPLIST *sl = (SKIPLIST*) malloc(sizeof(SKIPLIST));
    sl->levelmax = LEVEL_MAX;
    
    NO* x = (NO*) malloc(sizeof(NO));
    sl->upleft = x;
    ITEM* item = item_criar("0", "0");
    
    for(int i = sl->levelmax; i >= 0; --i) {
        x->item = item;
        x->nivel = i;
        x->proximo = NULL;
        if(i == 0) {
            x->baixo = NULL;
        } else {
            NO* y = (NO*) malloc(sizeof(NO));
            x->baixo = y;
            x = y;
        }
    }
    
    return(sl);
}

int skip_inserir(ITEM* item, SKIPLIST* skiplist) {

    if((skiplist == NULL) || (skip_cheia(skiplist) == 1)) {
        printf("Erro\n");
        return 0;
    }

    NO* atual = skiplist->upleft;
    NO** aux = (NO**) malloc((LEVEL_MAX + 1) * sizeof(NO*));

    for(int i = LEVEL_MAX; i >= 0; --i) {
        aux[i] = NULL;
    }

    for(int i = LEVEL_MAX; i >= 0; --i) {
        if(atual->proximo != NULL) {
            while(strcmp(item_get_verbete(atual->proximo->item), item_get_verbete(item)) < 0) {
                printf("%s\n", item_get_verbete(atual->item));
                atual = atual->proximo;
                if(atual->proximo == NULL) {
                    break;
                }
            }
        }
        aux[i] = atual;
        if(atual->baixo != NULL) {
            atual = atual->baixo; 
        }
    }

    if(atual != NULL) {
        atual = atual->proximo;
    }

    if(atual == NULL) {
        printf("y");
    }

    int verify = 0;

    if(atual == NULL) {
        verify = 1;
    } else {
        printf("%s\n", item_get_verbete(atual->item));
        if(strcmp(item_get_verbete(atual->item), item_get_verbete(item)) != 0) {
            verify = 1;
        }
    }

    if(verify == 1) {

        int n = gerar_nivel();
        printf("%d\n", n);

        NO* new = (NO*) malloc(sizeof(NO));
        NO* reserva = new;

        for(int i = n; i >= 0; --i) {
            new->item = item;
            new->nivel = i;
            new->proximo = NULL;
            if(i == 0) {
                new->baixo = NULL;
            } else {
                NO* y = (NO*) malloc(sizeof(NO));
                new->baixo = y;
                new = y;
            }
        }

        new = reserva;

        for(int i = n; i >= 0; i--) {
            new->proximo = (aux[i])->proximo;
            (aux[i])->proximo = new;
            new = new->baixo;
        }

        free(aux);
        return 1;
    }

    printf("erro");
    return 0;

}

int skip_alterar(ITEM* item, SKIPLIST* skiplist) {
    if (skiplist != NULL && skip_vazia(skiplist) == 0) {
        NO* sentinela = skiplist->upleft;

        while (sentinela != NULL) {
            if (sentinela->proximo != NULL) {
                int cmp = strcmp(item_get_verbete(sentinela->proximo->item), item_get_verbete(item));
                if (cmp == 0) {
                    item_set_definicao(sentinela->proximo->item, item_get_definicao(item));
                    return 1;
                } else if (cmp < 0) {
                    sentinela = sentinela->proximo;
                } else {
                    sentinela = sentinela->baixo;
                }
            } else {
                sentinela = sentinela->baixo;
            }
        }
    }

    return 0;
}

int skip_remover(char* verbete, SKIPLIST* skiplist) {

    if((skiplist == NULL) || (skip_cheia(skiplist) == 1)) {
        return 0;
    }

    
}

ITEM* skip_busca(char* verbete, SKIPLIST* skiplist) {
    if (skiplist == NULL || skip_vazia(skiplist) == 1) {
        return NULL;
    }

    NO* sentinela = skiplist->upleft;

    while (sentinela != NULL) {
        if (sentinela->proximo != NULL) {
            int cmp = strcmp(item_get_verbete(sentinela->proximo->item), verbete);
            if (cmp == 0) {
                return sentinela->proximo->item;
            } else if (cmp < 0) {
                sentinela = sentinela->proximo;
            } else {
                sentinela = sentinela->baixo;
            }
        } else {
            sentinela = sentinela->baixo;
        }
    }

    return NULL;
}

int skip_imprimir(char ch, SKIPLIST* skiplist) {

    if((skiplist == NULL) || (skip_cheia(skiplist) == 1)) {
        printf("Erro\n");
        return 0;
    }

    NO* sentinela = skiplist->upleft;
    NO* aux = sentinela;

    while(aux != NULL) {
        item_imprimir_completo(aux->item);
        printf(" %d\n", aux->nivel);
        if(aux->proximo != NULL) {
            aux = aux->proximo;
        } else {
            sentinela = sentinela->baixo;
            aux = sentinela;
        }
    }

    return 1;

    
}

int skip_vazia(SKIPLIST* sl) {
    if(sl == NULL) {
        return 1;
    }

    NO* aux = sl->upleft;
    while(aux->baixo != NULL) {
        aux = aux->baixo;
    }

    if(aux->proximo == NULL) {
        return 1;
    }
    
    return 0;
}

int skip_cheia(SKIPLIST* skiplist) {
    NO* no;

    no = (NO*) malloc(sizeof(NO));

    if(no == NULL)
        return 1;
    return 0;
}

void skip_apagar(SKIPLIST** skiplist) {
    if (*skiplist != NULL) {
        NO* sentinela = (*skiplist)->upleft;
        NO* aux;
        NO* reserva;

        while (sentinela->baixo != NULL) {
            reserva = sentinela;
            while(reserva != NULL) {
                aux = reserva->proximo;
                free(reserva);
                reserva = aux;
            }
            sentinela = sentinela->baixo;
        }

        while(sentinela != NULL) {
            aux = sentinela->proximo;
            item_apagar(&(sentinela->item));
            free(sentinela);
            sentinela = aux;
        }

        free(*skiplist);
        *skiplist = NULL;
    }
}


int gerar_nivel() {
    int lvl = 0;
    
    while(lvl < LEVEL_MAX) {
        if(rand()%2) {
            ++lvl;
        } else {
            break;
        }
    }
    return(lvl);
}
