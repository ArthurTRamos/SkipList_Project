#include "skiplist.h"

int main(void) {
    srand(time(0));
    char operacao[15], verbete[55], definicao[160];
    char ch = '!';
    int flag = 0;
    SKIPLIST* skiplist;

    skiplist = skip_criar();
    
    if(skiplist != NULL) {
        while(flag != EOF) {
            int i = 0;
            ch = '!';
            while (1) {
                flag = scanf("%c", &ch);
                if (flag == EOF || ch == ' ') {
                    i++;
                    break;
                }
                operacao[i] = ch;
                i++;
            }
            if (flag == EOF)
                break;
            operacao[i - 1] = '\0';

            if(strcmp(operacao, "insercao") == 0) {
                i = 0;
                ch = '!';
                while(ch != ' ') {
                    scanf("%c", &ch);
                    verbete[i] = ch;
                    i++;
                }
                verbete[i-1] = '\0';
                
                i = 0;

                while(ch != '\n' && ch != 13) {
                    flag = scanf("%c", &ch);
                    if(flag == EOF)
                        break;
                    definicao[i] = ch;
                    i++;
                }
                if(ch == 13)
                    scanf("%c", &ch);
                definicao[i-1] = '\0';

                ITEM* item = item_criar(verbete, definicao);
                if(skip_inserir(item, skiplist) == 0)
                    printf("OPERACAO INVALIDA\n");

                if(flag == EOF)
                    break;
            }

            if(strcmp(operacao, "remocao") == 0) {
                i = 0;
                ch = '!';
                while(ch != '\n' && ch != 13) {
                    flag = scanf("%c", &ch);
                    if(flag == EOF)
                        break;
                    verbete[i] = ch;
                    i++;
                }
                if(ch == 13)
                    scanf("%c", &ch);
                verbete[i-1] = '\0';

                if(skip_remover(verbete, skiplist) == 0)
                    printf("OPERACAO INVALIDA\n");

                if(flag == EOF)
                    break;
            }

            if(strcmp(operacao, "alteracao") == 0) {
                i = 0;
                ch = '!';
                while(ch != ' ') {
                    scanf("%c", &ch);
                    verbete[i] = ch;
                    i++;
                }
                verbete[i-1] = '\0';
                
                i = 0;

                while(ch != '\n' && ch != 13) {
                    flag = scanf("%c", &ch);
                    if(flag == EOF)
                        break;
                    definicao[i] = ch;
                    i++;
                }
                if(ch == 13)
                    flag = scanf("%c", &ch);
                definicao[i-1] = '\0';

                ITEM* item = item_criar(verbete, definicao);
                if(skip_alterar(item, skiplist) == 0)
                    printf("OPERACAO INVALIDA\n");

                if(flag == EOF)
                    break;

            }

            if(strcmp(operacao, "busca") == 0) {
                i = 0;
                ch = '!';
                while(ch != '\n' && ch != 13) {
                    flag = scanf("%c", &ch);
                    if(flag == EOF)
                        break;
                    verbete[i] = ch;
                    i++;
                }
                verbete[i-1] = '\0';

                if(ch == 13)
                    scanf("%c", &ch);
                
                ITEM* item = skip_busca(verbete, skiplist);
                if(item == NULL)
                    printf("OPERACAO INVALIDA\n");
                else
                    item_imprimir_completo(item);

                if(flag == EOF)
                    break;
            }

            if(strcmp(operacao, "impressao") == 0) {
                scanf("%c", &ch);
                skip_imprimir(ch, skiplist);
                flag = scanf("%c", &ch);
                if(ch == 13)
                    scanf("%c", &ch);
                if(flag == EOF)
                    break;
            }
        }
    }

    skip_apagar(&skiplist);

    return 0;
}